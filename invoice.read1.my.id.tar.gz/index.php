<?php
include 'app/config/auth.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sistem Invoice Landing Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5">

    <div class="text-center mb-5">
        <h2>🚀 Sistem Invoice</h2>
        <p class="text-muted">Cek invoice & lakukan pembayaran dengan mudah</p>
    </div>

    <div class="row justify-content-center">

        <!-- CEK INVOICE (PUBLIC) -->
        <div class="col-md-5">
            <div class="card shadow-sm">
                <div class="card-body text-center">

                    <h5>Cek Invoice</h5>
                    <p class="text-muted">Masukkan kode invoice Anda</p>

                    <form action="app/invoice/invoice.php" method="GET">
                        <input type="text" name="kode" class="form-control mb-3" placeholder="Contoh: INV-123456" required>
                        <button class="btn btn-dark w-100">Lihat Invoice</button>
                    </form>

                </div>
            </div>
        </div>

    </div>

    <!-- ADMIN (TERSEMBUNYI / TERBATAS) -->
    <div class="text-center mt-5">
        <?php if(isset($_SESSION['user'])): ?>
            <a href="app/admin/dashboard.php" class="btn btn-primary">Masuk Dashboard</a>
        <?php else: ?>
            <a href="login.php" class="btn btn-outline-secondary btn-sm">Login Admin</a>
        <?php endif; ?>
    </div>

    <div class="text-center mt-4 text-muted">
        <small>© <?php echo date('Y'); ?> Sistem Invoice</small>
    </div>

</div>

</body>
</html>