<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'app/config/koneksi.php';
include 'app/config/auth.php';

// jika sudah login
if(isset($_SESSION['user'])){
    header("Location: app/admin/dashboard.php");
    exit;
}

if(isset($_POST['login'])){

    if(!isset($_POST['csrf']) || !check_csrf($_POST['csrf'])){
        die("CSRF invalid");
    }

    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // cek koneksi
    if(!$conn){
        die("Koneksi database gagal");
    }

    $stmt = $conn->prepare("SELECT * FROM admin WHERE username=? LIMIT 1");

    if(!$stmt){
        die("Query error: " . $conn->error);
    }

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if($user && password_verify($password, $user['password'])){

        session_regenerate_id(true);

        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role'] ?? 'admin'
        ];

        header("Location: app/admin/dashboard.php");
        exit;

    } else {
        $error = "Username atau password salah";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-5" style="max-width:400px;">
    <div class="card shadow-sm p-4">

        <h4 class="text-center mb-3">Login Admin</h4>

        <?php if(isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf" value="<?php echo csrf(); ?>">

            <div class="mb-3">
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>

            <div class="mb-3">
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <button name="login" class="btn btn-primary w-100">Login</button>
        </form>

    </div>
</div>

</body>
</html>