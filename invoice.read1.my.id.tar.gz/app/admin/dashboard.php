<?php
include '../config/koneksi.php';
include '../config/auth.php';
include '../layout/header.php';

requireLogin();

// =======================
// TOTAL DATA
// =======================
$totalInvoice = $conn->query("SELECT COUNT(*) as total FROM invoices")
->fetch_assoc()['total'] ?? 0;

$totalOmzet = $conn->query("
SELECT COALESCE(SUM(total),0) as total 
FROM invoices 
WHERE status='PAID'
")->fetch_assoc()['total'] ?? 0;

// =======================
// GRAFIK
// =======================
$chart = $conn->query("
SELECT DATE(created_at) as tgl, COALESCE(SUM(total),0) as omzet
FROM invoices
WHERE status='PAID'
GROUP BY DATE(created_at)
ORDER BY tgl ASC
");

$tgl = [];
$omzet = [];

while($row = $chart->fetch_assoc()){
    $tgl[] = $row['tgl'];
    $omzet[] = (int)$row['omzet'];
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Invoice</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="container mt-4">

<h4 class="mb-3">Dashboard Invoice</h4>

<!-- INFO -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card p-3">
            <h6>Total Invoice</h6>
            <h4><?= $totalInvoice ?></h4>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card p-3">
            <h6>Total Omzet</h6>
            <h4>Rp <?= number_format($totalOmzet) ?></h4>
        </div>
    </div>
</div>

<!-- TABLE -->
<table class="table table-bordered table-hover">

<tr>
    <th>Kode</th>
    <th>Jenis</th>
    <th>Total</th>
    <th>Status</th>
    <th>Tanggal</th>
    <th>Aksi</th>
</tr>

<?php
$data = $conn->query("SELECT * FROM invoices ORDER BY id DESC");

while($d = $data->fetch_assoc()){

    $isPaid = strtoupper($d['status']) == 'PAID';

    $statusBadge = $isPaid 
        ? "<span class='badge bg-success'>PAID</span>"
        : "<span class='badge bg-danger'>UNPAID</span>";

    $jenisBadge = $d['jenis']=='servis_laptop'
        ? "<span class='badge bg-warning'>Servis</span>"
        : "<span class='badge bg-primary'>Landing</span>";

    if(!$isPaid){
        $aksi = "
            <a href='../invoice/invoice.php?kode={$d['invoice_code']}' class='btn btn-dark btn-sm'>Lihat</a>

            <a href='mark_paid.php?id={$d['id']}' 
               class='btn btn-success btn-sm'
               onclick=\"return confirm('Tandai sebagai PAID & kirim WA?')\">
               ✔ Paid
            </a>
        ";
    } else {
        $aksi = "
            <a href='../invoice/invoice.php?kode={$d['invoice_code']}' class='btn btn-dark btn-sm'>Lihat</a>
            <span class='badge bg-secondary'>Selesai</span>
        ";
    }

    echo "<tr>
        <td>{$d['invoice_code']}</td>
        <td>$jenisBadge</td>
        <td>Rp ".number_format((int)$d['total'])."</td>
        <td>$statusBadge</td>
        <td>".date('d-m-Y H:i', strtotime($d['created_at']))."</td>
        <td>$aksi</td>
    </tr>";
}
?>

</table>

<!-- CHART -->
<div class="card p-3 mt-4">
    <h6>Grafik Omzet</h6>
    <canvas id="chartOmzet"></canvas>
</div>

<script>
const labels = <?= json_encode($tgl); ?>;
const data = <?= json_encode($omzet); ?>;

new Chart(document.getElementById('chartOmzet'), {
    type: 'line',
    data: {
        labels: labels,
        datasets: [{
            label: 'Omzet (Rp)',
            data: data,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true }
        }
    }
});
</script>

</body>
</html>