<?php
include '../config/koneksi.php';
include '../config/auth.php';
include '../layout/header.php';

requireLogin();
requireRole('admin');

$id = intval($_GET['id']);

$data = $conn->query("SELECT * FROM admin WHERE id=$id")->fetch_assoc();

if(isset($_POST['submit'])){

    if(!check_csrf($_POST['csrf'])){
        die("CSRF invalid");
    }

    $username = $_POST['username'];
    $role     = $_POST['role'];

    if(!empty($_POST['password'])){
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE admin SET username=?, password=?, role=? WHERE id=?");
        $stmt->bind_param("sssi", $username, $password, $role, $id);
    } else {
        $stmt = $conn->prepare("UPDATE admin SET username=?, role=? WHERE id=?");
        $stmt->bind_param("ssi", $username, $role, $id);
    }

    $stmt->execute();
    header("Location: admin.php");
}
?>

<form method="POST" class="container mt-4">
<h3>Edit Admin</h3>

<input type="hidden" name="csrf" value="<?= csrf(); ?>">

<input name="username" value="<?= $data['username'] ?>" class="form-control mb-2">

<input type="password" name="password" class="form-control mb-2" placeholder="Kosongkan jika tidak diubah">

<select name="role" class="form-control mb-2">
  <option value="admin" <?= $data['role']=='admin'?'selected':'' ?>>Admin</option>
  <option value="staff" <?= $data['role']=='staff'?'selected':'' ?>>Staff</option>
</select>

<button name="submit" class="btn btn-warning">Update</button>
</form>