<?php
session_start();
include '../config/koneksi.php';

// ======================
// VALIDASI ID
// ======================
if(!isset($_GET['id'])){
    die("ID tidak ditemukan");
}

$id = intval($_GET['id']);

// ======================
// AMBIL DATA + JOIN CUSTOMER
// ======================
$data = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT invoices.*, customers.nomor_wa, customers.nama
    FROM invoices
    JOIN orders ON invoices.order_id = orders.id
    JOIN customers ON orders.customer_id = customers.id
    WHERE invoices.id = '$id'
"));

if(!$data){
    die("Data invoice tidak ditemukan");
}

// ======================
// CEK SUDAH PAID
// ======================
if(strtoupper($data['status']) == 'PAID'){
    header("Location: dashboard.php?msg=sudah_paid");
    exit;
}

// ======================
// FORMAT NOMOR (AMAN)
// ======================
function formatNomor($nomor){
    $nomor = preg_replace('/[^0-9]/', '', $nomor);

    if(substr($nomor, 0, 1) == '0'){
        $nomor = '62' . substr($nomor, 1);
    }

    return $nomor;
}

$nomor = formatNomor($data['nomor_wa']);

// validasi nomor
if(empty($nomor) || strlen($nomor) < 10){
    header("Location: dashboard.php?msg=nomor_invalid");
    exit;
}

// ======================
// UPDATE STATUS
// ======================
$update = mysqli_query($conn, "UPDATE invoices SET status='PAID' WHERE id='$id'");

if(!$update){
    die("Gagal update status");
}

// ======================
// KIRIM WHATSAPP
// ======================
$token = "txPT7Kf2qNRCA8uadHgK"; // ganti token

$link = "https://invoice.read1.my.id/app/invoice/invoice.php?kode=".$data['invoice_code'];

$pesan = "*PEMBAYARAN BERHASIL* \n\n"
       . "Halo Bapak/Ibu/Kakak ".$data['nama'].",\n\n"
       . "Terima kasih, pembayaran Anda telah kami terima.\n\n"
       . "━━━━━━━━━━━━━━━\n"
       . "📄 Invoice : ".$data['invoice_code']."\n"
       . "💰 Total   : Rp ".number_format($data['total'],0,',','.')."\n"
       . "━━━━━━━━━━━━━━━\n";

// ======================
// TAMBAHAN KETERANGAN
// ======================
if(!empty($data['keterangan'])){
    $pesan .= "\n📝 Keterangan:\n".$data['keterangan']."\n";
}

$pesan .= "\n🔗 Lihat Invoice:\n".$link."\n\n"
        . "Terima kasih atas kepercayaan Anda 🙏";

// CURL (VERSI STABIL)
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://api.fonnte.com/send",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_POSTFIELDS => http_build_query([
        'target'  => $nomor,
        'message' => $pesan,
    ]),
    CURLOPT_HTTPHEADER => [
        "Authorization: $token"
    ],
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

// OPTIONAL LOG (biar gampang cek kalau error)
file_put_contents('log_wa.txt', $response.PHP_EOL, FILE_APPEND);

// ======================
// REDIRECT
// ======================
header("Location: dashboard.php?msg=paid_success");
exit;