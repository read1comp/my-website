<?php
include '../config/koneksi.php';
include '../config/auth.php';

requireLogin();
requireRole('admin');

/* =========================
   HANDLE POST (WAJIB DI ATAS)
========================= */
if(isset($_POST['submit'])){

    if(!check_csrf($_POST['csrf'])){
        die("CSRF invalid");
    }

    $username = trim($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role     = $_POST['role'];

    if(!empty($username) && !empty($_POST['password'])){

        $stmt = $conn->prepare("INSERT INTO admin(username,password,role) VALUES(?,?,?)");
        $stmt->bind_param("sss", $username, $password, $role);
        $stmt->execute();

        header("Location: admin.php");
        exit;
    }
}
?>

<?php include '../layout/header.php'; ?>

<style>
.admin-box {
    max-width:500px;
    margin:30px auto;
    background:#fff;
    padding:40px;
    border-radius:20px;
    box-shadow:0 15px 40px rgba(0,0,0,0.1);
}

.admin-box h3 {
    text-align:center;
    margin-bottom:25px;
}

.admin-input {
    width:100%;
    padding:14px;
    margin-bottom:15px;
    border-radius:12px;
    border:1px solid #ddd;
}

.admin-btn {
    width:100%;
    padding:14px;
    border:none;
    border-radius:12px;
    background:#22c55e;
    color:#fff;
}
</style>

<div class="admin-box">

    <h3>Tambah Admin</h3>

    <form method="POST">

        <input type="hidden" name="csrf" value="<?= csrf(); ?>">

        <input name="username" class="admin-input" placeholder="Username" required>

        <input type="password" name="password" class="admin-input" placeholder="Password" required>

        <select name="role" class="admin-input">
            <option value="admin">Admin</option>
            <option value="staff">Staff</option>
        </select>

        <button class="admin-btn" name="submit">Simpan</button>

    </form>

</div>