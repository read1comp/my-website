<?php
include '../config/koneksi.php';
include '../config/auth.php';
include '../layout/header.php';
requireLogin();

function formatNomor($nomor){
    $nomor = preg_replace('/[^0-9]/', '', $nomor);

    if(substr($nomor, 0, 1) == '0'){
        $nomor = '62' . substr($nomor, 1);
    }

    return $nomor;
}

if(isset($_POST['submit'])){

    if(!check_csrf($_POST['csrf'])){
        die("CSRF invalid");
    }

    // =====================
    // INPUT
    // =====================
    $nama  = trim($_POST['nama']);
    $wa    = formatNomor($_POST['wa']);
    $total = intval($_POST['total']);
    $jenis = $_POST['jenis'];
    $keterangan = trim($_POST['keterangan']);

    if(empty($nama) || empty($wa) || $total <= 0){
        die("Data tidak valid");
    }

    // =====================
    // CREATE CUSTOMER
    // =====================
    $stmt = $conn->prepare("INSERT INTO customers(nama,nomor_wa) VALUES(?,?)");
    $stmt->bind_param("ss", $nama, $wa);
    $stmt->execute();
    $cid = $stmt->insert_id;

    // =====================
    // CREATE ORDER
    // =====================
    $stmt = $conn->prepare("INSERT INTO orders(customer_id,harga) VALUES(?,?)");
    $stmt->bind_param("ii", $cid, $total);
    $stmt->execute();
    $oid = $stmt->insert_id;

    // =====================
    // INVOICE CODE
    // =====================
    $tanggal = date("Ymd");

    $q = $conn->query("
        SELECT COUNT(*) as total 
        FROM invoices 
        WHERE DATE(created_at) = CURDATE()
    ");

    $row = $q->fetch_assoc();
    $urutan = $row['total'] + 1;

    $kode = "INV-" . $tanggal . "-" . str_pad($urutan, 3, "0", STR_PAD_LEFT);

    // =====================
    // INSERT INVOICE
    // =====================
    $status = "UNPAID";

    $stmt = $conn->prepare("
        INSERT INTO invoices(order_id,invoice_code,total,status,jenis,keterangan) 
        VALUES(?,?,?,?,?,?)
    ");
    $stmt->bind_param("isssss", $oid, $kode, $total, $status, $jenis, $keterangan);
    $stmt->execute();

    // =====================
    // LINK
    // =====================
    $link = "https://invoice.read1.my.id/app/invoice/invoice.php?kode=".$kode;

    // =====================
    // PESAN WA (PROFESIONAL)
    // =====================
    $pesan = "📄 *INVOICE BARU*\n\n";
    $pesan .= "Halo Bapak/Ibu/Kakak *$nama*,\n\n";
    $pesan .= "Invoice Anda telah dibuat dengan detail berikut:\n\n";
    $pesan .= "━━━━━━━━━━━━━━━\n";
    $pesan .= "📄 Kode : $kode\n";
    $pesan .= "💰 Total : Rp " . number_format($total,0,',','.') . "\n";
    $pesan .= "━━━━━━━━━━━━━━━\n";

    if(!empty($keterangan)){
        $pesan .= "\n📝 Keterangan:\n$keterangan\n";
    }

    $pesan .= "\n🔗 Pembayaran & Detail:\n$link\n\n";
    $pesan .= "Silakan lakukan pembayaran sesuai invoice.\n";
    $pesan .= "Terima kasih 🙏";

    // =====================
    // KIRIM WA (STABIL)
    // =====================
    $token = "txPT7Kf2qNRCA8uadHgK";

    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://api.fonnte.com/send",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_POSTFIELDS => http_build_query([
            'target'  => $wa,
            'message' => $pesan,
        ]),
        CURLOPT_HTTPHEADER => [
            "Authorization: $token"
        ],
    ]);

    $response = curl_exec($curl);
    curl_close($curl);

    // optional log
    file_put_contents('log_wa.txt', $response.PHP_EOL, FILE_APPEND);

    // redirect
    header("Location: ../admin/dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Create Invoice</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
/* Chrome, Safari, Edge */
input[type=number]::-webkit-outer-spin-button,
input[type=number]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
}

/* Firefox */
input[type=number] {
    -moz-appearance: textfield;
}
</style>
<script>
document.addEventListener('DOMContentLoaded', function(){
    const numberInput = document.querySelector('input[name="total"]');

    numberInput.addEventListener('wheel', function(e){
        e.preventDefault();
    });
});
</script>
</head>

<body class="container mt-5">

<h3>Buat Invoice</h3>

<div class="alert alert-info">
    Isi data dengan benar. Invoice akan langsung dikirim ke WhatsApp customer.
</div>

<a href="dashboard.php" class="btn btn-secondary mb-3">← Kembali</a>

<form method="POST">

    <input type="hidden" name="csrf" value="<?php echo csrf(); ?>">

    <div class="mb-3">
        <label>Nama Customer</label>
        <input type="text" name="nama" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>WhatsApp</label>
        <input type="text" name="wa" class="form-control" placeholder="08xxxx" required>
        <small class="text-muted">Nomor akan otomatis diubah ke format 62</small>
    </div>

    <div class="mb-3">
        <label>Total (Rp)</label>
        <input type="number" name="total" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Jenis Layanan</label>
        <select name="jenis" class="form-control">
            <option value="landingpage">Landing Page</option>
            <option value="servis_laptop">Servis Laptop</option>
        </select>
    </div>

    <div class="mb-3">
        <label>Keterangan (Opsional)</label>
        <textarea name="keterangan" class="form-control" rows="3"></textarea>
    </div>

    <button name="submit" class="btn btn-success w-100">
        Buat Invoice & Kirim WA
    </button>

</form>

</body>
</html>