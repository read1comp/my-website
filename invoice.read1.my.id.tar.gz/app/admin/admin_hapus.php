<?php
include '../config/koneksi.php';
include '../config/auth.php';
include '../layout/header.php';

requireLogin();
requireRole('admin');

if(!check_csrf($_POST['csrf'])){
    die("CSRF invalid");
}

$id = intval($_POST['id']);

// cegah hapus diri sendiri
if($_SESSION['user']['id'] == $id){
    die("Tidak bisa hapus akun sendiri");
}

$stmt = $conn->prepare("DELETE FROM admin WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: admin.php");