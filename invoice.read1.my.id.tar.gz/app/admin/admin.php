<?php
include '../config/koneksi.php';
include '../config/auth.php';
include '../layout/header.php';

requireLogin();

// hanya admin yang boleh akses
requireRole('admin');

$data = $conn->query("SELECT * FROM admin ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Manajemen Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="container mt-4">

<h3>👥 Manajemen Admin</h3>

<a href="dashboard.php" class="btn btn-secondary mb-3">← Kembali</a>
<a href="admin_tambah.php" class="btn btn-primary mb-3">+ Tambah Admin</a>

<table class="table table-bordered">
<tr>
  <th>Username</th>
  <th>Role</th>
  <th>Aksi</th>
</tr>

<?php while($d = $data->fetch_assoc()): ?>
<tr>
  <td><?= $d['username'] ?></td>
  <td><?= $d['role'] ?></td>
  <td>
    <a href="admin_edit.php?id=<?= $d['id'] ?>" class="btn btn-sm btn-warning">Edit</a>

    <form method="POST" action="admin_hapus.php" style="display:inline;">
        <input type="hidden" name="id" value="<?= $d['id'] ?>">
        <input type="hidden" name="csrf" value="<?= csrf(); ?>">
        <button class="btn btn-sm btn-danger"
        onclick="return confirm('Hapus admin ini?')">Hapus</button>
    </form>
  </td>
</tr>
<?php endwhile; ?>

</table>

</body>
</html>