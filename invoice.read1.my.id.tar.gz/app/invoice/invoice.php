<?php
include '../config/koneksi.php';
include '../config/auth.php';

// ambil kode dari URL
$kode = $_GET['kode'] ?? '';

if(empty($kode)){
    die("Invoice tidak ditemukan");
}

// ambil data invoice + join customer
$query = $conn->prepare("
SELECT invoices.*, customers.nama 
FROM invoices
JOIN orders ON invoices.order_id = orders.id
JOIN customers ON orders.customer_id = customers.id
WHERE invoice_code=?
");
$query->bind_param("s", $kode);
$query->execute();

$data = $query->get_result()->fetch_assoc();

if(!$data){
    die("Invoice tidak ditemukan");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Invoice <?php echo $data['invoice_code']; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<div class="container mt-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    
    <h4>
        📄 Invoice <?php echo $data['invoice_code']; ?>
        <span class="badge bg-<?php echo $data['status']=='PAID' ? 'success' : 'danger'; ?>">
            <?php echo $data['status']; ?>
        </span>
    </h4>

</div>

<!-- CARD -->
<div class="card shadow-sm p-4">

    <h5 class="mb-3">Detail Invoice</h5>

    <p>
        <strong>Nama Customer:</strong> 
        Bapak/Ibu/Kakak <?php echo htmlspecialchars($data['nama']); ?>
    </p>

    <p><strong>Jenis Layanan:</strong> 
        <?php echo $data['jenis']=='servis_laptop' ? 'Servis Laptop' : 'Landing Page'; ?>
    </p>

    <p><strong>Total:</strong> Rp <?php echo number_format($data['total']); ?></p>

    <hr>

    <h6 class="mb-3">Pembayaran</h6>

    <p>Scan QRIS berikut untuk melakukan pembayaran:</p>

    <img src="../assets/qris/qris.jpeg" width="220">

    <p class="mt-3 text-muted">
        Setelah pembayaran, mohon konfirmasi ke admin. <br> Terimakasih </br>
    </p>

</div>

</div>

</body>
</html>