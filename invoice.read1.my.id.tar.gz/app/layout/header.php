<?php
if(session_status() === PHP_SESSION_NONE){
    session_start();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Sistem Invoice</title>

    <!-- BOOTSTRAP (WAJIB) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- FIX STYLE NAV -->
    <style>

        body{
            background:#f5f6fa;
        }

        /* NAVBAR MODERN */
        .navbar{
            background: linear-gradient(135deg,#0f172a,#111827);
            box-shadow:0 6px 20px rgba(0,0,0,0.25);
        }

        .navbar-nav{
            list-style:none;
            padding-left:0;
            margin-bottom:0;
        }

        .navbar-nav .nav-item{
            list-style:none;
        }

        .navbar-nav .nav-link{
            color:#cbd5e1 !important;
            padding:8px 14px;
            border-radius:8px;
            transition:0.3s;
        }

        .navbar-nav .nav-link:hover{
            background:rgba(255,255,255,0.08);
            color:#fff !important;
        }

        .navbar-brand img{
            height:32px;
            margin-right:10px;
            border-radius:6px;
        }

        .user-box{
            color:#fff;
            display:flex;
            align-items:center;
            gap:10px;
        }

        .badge-role{
            font-size:11px;
            background:#374151;
            padding:3px 8px;
            border-radius:10px;
        }

        .btn-logout{
            background:#ef4444;
            border:none;
            padding:6px 12px;
            border-radius:8px;
            color:#fff;
            font-size:13px;
        }

        .btn-logout:hover{
            background:#dc2626;
        }
        
        /* ===== RESPONSIVE FIX UNTUK MOBILE ===== */
@media (max-width: 991px){

    .navbar-nav{
        margin-top:15px;
    }

    .navbar-nav .nav-link{
        display:block;
        width:100%;
        margin-bottom:5px;
    }

    .user-box{
        flex-direction:column;
        align-items:flex-start;
        gap:8px;
        margin-top:15px;
        width:100%;
    }

    .btn-logout{
        width:100%;
        text-align:center;
    }

    .navbar-collapse{
        background:#0f172a;
        padding:15px;
        border-radius:10px;
        margin-top:10px;
    }

}

    </style>

</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark mb-4">
  <div class="container">

    <a class="navbar-brand d-flex align-items-center" href="/app/admin/dashboard.php">
        <img src="/logo.png" alt="Logo">
        <span>Sistem Invoice</span>
    </a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="nav">

      <ul class="navbar-nav me-auto">

        <li class="nav-item">
          <a class="nav-link" href="/app/admin/dashboard.php">Dashboard</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="/app/admin/create_invoice.php">Buat Invoice</a>
        </li>

        <?php if(isset($_SESSION['user']) && $_SESSION['user']['role']=='admin'): ?>
        <li class="nav-item">
          <a class="nav-link" href="/app/admin/admin.php">Manajemen Admin</a>
        </li>
        <?php endif; ?>

      </ul>

      <!-- USER -->
      <div class="user-box ms-lg-auto">

        <?php if(isset($_SESSION['user'])): ?>

            <span>
                👤 <?php echo $_SESSION['user']['username']; ?>
                <span class="badge-role">
                    <?php echo $_SESSION['user']['role']; ?>
                </span>
            </span>

            <a href="/logout.php" class="btn-logout">
                Logout
            </a>

        <?php else: ?>

            <a href="/login.php" class="btn btn-primary btn-sm">
                Login
            </a>

        <?php endif; ?>

      </div>

    </div>

  </div>
</nav>

<!-- BOOTSTRAP JS (WAJIB) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>