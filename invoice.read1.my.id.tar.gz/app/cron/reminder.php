<?php
include '../config/koneksi.php';

date_default_timezone_set("Asia/Jakarta");

$today = date('Y-m-d');

// ambil invoice H-1 jatuh tempo
$data = mysqli_query($conn,"
SELECT invoices.*, customers.nama, customers.nomor_wa
FROM invoices
JOIN orders ON orders.id = invoices.order_id
JOIN customers ON customers.id = orders.customer_id
WHERE invoices.status='UNPAID'
AND invoices.due_date = DATE_ADD('$today', INTERVAL 1 DAY)
");

while($d = mysqli_fetch_assoc($data)){

    $nama = $d['nama'];
    $wa   = $d['nomor_wa'];
    $kode = $d['invoice_code'];
    $total= number_format($d['total']);

    // link invoice
    $link = "https://domainmu.com/app/invoice/invoice.php?kode=".$kode;

    // pesan
    $pesan = "Halo $nama\n";
    $pesan .= "Reminder invoice Anda jatuh tempo BESOK\n\n";
    $pesan .= "Kode: $kode\n";
    $pesan .= "Total: Rp $total\n\n";
    $pesan .= "Silakan bayar di sini:\n$link";

    // ======================
    // KIRIM WA (Fonnte)
    // ======================
    $token = "ISI_TOKEN_FONNTE";

    $curl = curl_init();
    curl_setopt_array($curl, [
      CURLOPT_URL => "https://api.fonnte.com/send",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_POSTFIELDS => [
        'target' => $wa,
        'message' => $pesan,
      ],
      CURLOPT_HTTPHEADER => [
        "Authorization: $token"
      ],
    ]);

    curl_exec($curl);
    curl_close($curl);

    echo "Reminder terkirim ke $nama ($kode)\n";
}
?>