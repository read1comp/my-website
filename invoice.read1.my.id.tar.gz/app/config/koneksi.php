<?php
$conn = mysqli_connect(
    "localhost",
    "sql_invoice_read1_my_id",
    "b53da7f34a3788",
    "sql_invoice_read1_my_id"
);

if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
