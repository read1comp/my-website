<?php
session_start();

function isLogin(){
    return isset($_SESSION['user']);
}

function requireLogin(){
    if(!isLogin()){
        header("Location: /login.php");
        exit;
    }
}

// role check (opsional)
function requireRole($role){
    if($_SESSION['user']['role'] !== $role){
        header("Location: /app/admin/dashboard.php?error=forbidden");
        exit;
    }
}
// CSRF
if(empty($_SESSION['csrf'])){
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function csrf(){
    return $_SESSION['csrf'];
}

function check_csrf($token){
    return hash_equals($_SESSION['csrf'], $token);
}